/*
$(".uno").click(function(){
    console.log("avatar uno");
    var flag= true;
});

function updateImg(num){
   if(num===1) {
       $('#avatarN').load("./avatarEscogido.html").add("<img src='./images/avatar1.png' />").appendTo(document.body);
       $('.hi').add("<h3> hi </h3>").appendTo(document.body);
   }
}*/

$("input").change(function(e) {

    for (var i = 0; i < e.originalEvent.srcElement.files.length; i++) {
        
        var file = e.originalEvent.srcElement.files[i];
        var img = document.createElement("img");
        var reader = new FileReader();
        reader.onloadend = function() {
             img.src = reader.result;
        }
        reader.readAsDataURL(file);
        $("#contentImg").after(img);
    }
});

function btnSiguiente(){
    $(".atrasBtn").show(); 
}


function updateImg(num){
   if(num===1) {
       $('#avatar').load("./juegos.handlebars" ).add("<img src='./images/avatar1.png' />").appendTo('#avatar');
       window.load.href="/front";
   }
    
    else if(num===2) {
       $('#avatarSelected').load("./avatar.html" ).add("<img src='./images/avatar2.png' />").appendTo('#avatar');
   }
    
    else if(num===3) {
       $('#avatarSelected').load("./avatar.html" ).add("<img src='./images/avatar3.png' />").appendTo('#avatar');
   }
    
    else if(num===4) {
       $('#avatarSelected').load("./avatar.html" ).add("<img src='./images/avatar5.png' />").appendTo('#avatar');
   }
    
    else if(num===5) {
       $('#avatarSelected').load("./avatar.html" ).add("<img src='./images/avatar6.png' />").appendTo('#avatar');
   }
    else if(num===6) {
       $('#avatarSelected').load("./avatar.html" ).add("<img src='./images/avatar7.png' />").appendTo('#avatar');
   }
}